'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useComplaints } from '@/lib/complaint-context'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { AlertDialog, AlertDialogAction, AlertDialogContent, AlertDialogDescription, AlertDialogTitle } from '@/components/ui/alert-dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { CheckCircle } from 'lucide-react'

export default function SubmitComplaint() {
  const { addComplaint } = useComplaints()
  const [showSuccess, setShowSuccess] = useState(false)
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({
    studentName: '',
    matricNumber: '',
    email: '',
    category: '',
    description: '',
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleCategoryChange = (value: string) => {
    setFormData(prev => ({ ...prev, category: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!formData.studentName || !formData.matricNumber || !formData.email || !formData.category || !formData.description) {
      alert('Please fill in all fields')
      return
    }

    setLoading(true)
    try {
      addComplaint({
        studentName: formData.studentName,
        matricNumber: formData.matricNumber,
        email: formData.email,
        category: formData.category as 'academic' | 'lecturer' | 'result' | 'registration' | 'others',
        description: formData.description,
      })
      
      setFormData({
        studentName: '',
        matricNumber: '',
        email: '',
        category: '',
        description: '',
      })
      setShowSuccess(true)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      <main className="flex-1">
        <section className="py-12 md:py-24">
          <div className="container mx-auto px-4">
            <div className="max-w-2xl mx-auto">
              <h1 className="text-3xl md:text-4xl font-bold mb-2">Submit a Complaint</h1>
              <p className="text-muted-foreground mb-8">
                Please provide detailed information about your complaint so we can address it promptly.
              </p>

              <Card className="p-6 md:p-8">
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">Student Name</label>
                      <Input
                        type="text"
                        name="studentName"
                        placeholder="Enter your full name"
                        value={formData.studentName}
                        onChange={handleChange}
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Matric Number</label>
                      <Input
                        type="text"
                        name="matricNumber"
                        placeholder="e.g., ABU/CS/2021/001"
                        value={formData.matricNumber}
                        onChange={handleChange}
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Email Address</label>
                    <Input
                      type="email"
                      name="email"
                      placeholder="your.email@abu.edu.ng"
                      value={formData.email}
                      onChange={handleChange}
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Complaint Category</label>
                    <Select value={formData.category} onValueChange={handleCategoryChange}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="academic">Academic Issue</SelectItem>
                        <SelectItem value="lecturer">Lecturer Complaint</SelectItem>
                        <SelectItem value="result">Result Issue</SelectItem>
                        <SelectItem value="registration">Course Registration Issue</SelectItem>
                        <SelectItem value="others">Others</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Complaint Description</label>
                    <Textarea
                      name="description"
                      placeholder="Please describe your complaint in detail..."
                      value={formData.description}
                      onChange={handleChange}
                      rows={6}
                      required
                    />
                  </div>

                  <Button type="submit" className="w-full" disabled={loading}>
                    {loading ? 'Submitting...' : 'Submit Complaint'}
                  </Button>
                </form>
              </Card>
            </div>
          </div>
        </section>
      </main>

      <AlertDialog open={showSuccess} onOpenChange={setShowSuccess}>
        <AlertDialogContent>
          <AlertDialogTitle className="flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-green-600" />
            Complaint Submitted Successfully
          </AlertDialogTitle>
          <AlertDialogDescription>
            Thank you for submitting your complaint. We have received it and will review it shortly. You can track your complaint status in the View Complaints section.
          </AlertDialogDescription>
          <div className="flex gap-2 justify-end">
            <Link href="/complaints">
              <Button variant="outline">View Complaints</Button>
            </Link>
            <AlertDialogAction asChild>
              <Button>Back to Home</Button>
            </AlertDialogAction>
          </div>
        </AlertDialogContent>
      </AlertDialog>

      <Footer />
    </div>
  )
}
