'use client'

import { useState } from 'react'
import { useComplaints } from '@/lib/complaint-context'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Empty } from '@/components/ui/empty'
import { Clock, CheckCircle2, FileText } from 'lucide-react'

const categoryLabels: Record<string, string> = {
  academic: 'Academic Issue',
  lecturer: 'Lecturer Complaint',
  result: 'Result Issue',
  registration: 'Course Registration Issue',
  others: 'Others',
}

function formatDate(dateString: string) {
  return new Date(dateString).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  })
}

export default function ComplaintsPage() {
  const { complaints } = useComplaints()
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'resolved'>('all')

  const filteredComplaints = complaints.filter(c =>
    filterStatus === 'all' ? true : c.status === filterStatus
  )

  const pendingCount = complaints.filter(c => c.status === 'pending').length
  const resolvedCount = complaints.filter(c => c.status === 'resolved').length

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      <main className="flex-1">
        <section className="py-12 md:py-24">
          <div className="container mx-auto px-4">
            <h1 className="text-3xl md:text-4xl font-bold mb-2">Complaint Dashboard</h1>
            <p className="text-muted-foreground mb-8">
              Track all submitted complaints and their resolution status.
            </p>

            {/* Stats Cards */}
            <div className="grid md:grid-cols-3 gap-4 mb-8">
              <Card className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Total Complaints</p>
                    <p className="text-3xl font-bold">{complaints.length}</p>
                  </div>
                  <FileText className="h-8 w-8 text-primary opacity-50" />
                </div>
              </Card>

              <Card className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Pending</p>
                    <p className="text-3xl font-bold">{pendingCount}</p>
                  </div>
                  <Clock className="h-8 w-8 text-orange-500 opacity-50" />
                </div>
              </Card>

              <Card className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Resolved</p>
                    <p className="text-3xl font-bold">{resolvedCount}</p>
                  </div>
                  <CheckCircle2 className="h-8 w-8 text-green-600 opacity-50" />
                </div>
              </Card>
            </div>

            {/* Filter Tabs */}
            <Tabs value={filterStatus} onValueChange={(v) => setFilterStatus(v as 'all' | 'pending' | 'resolved')} className="mb-8">
              <TabsList>
                <TabsTrigger value="all">All</TabsTrigger>
                <TabsTrigger value="pending">Pending</TabsTrigger>
                <TabsTrigger value="resolved">Resolved</TabsTrigger>
              </TabsList>

              <TabsContent value={filterStatus} className="space-y-4">
                {filteredComplaints.length === 0 ? (
                  <div className="py-12">
                    <Empty
                      title="No complaints found"
                      description={
                        filterStatus === 'all'
                          ? 'No complaints have been submitted yet.'
                          : `No ${filterStatus} complaints at this time.`
                      }
                    />
                  </div>
                ) : (
                  filteredComplaints.map(complaint => (
                    <Card key={complaint.id} className="p-6 hover:shadow-lg transition-shadow">
                      <div className="grid md:grid-cols-4 gap-4 items-start mb-4">
                        <div>
                          <p className="text-sm text-muted-foreground">Student</p>
                          <p className="font-semibold">{complaint.studentName}</p>
                          <p className="text-sm text-muted-foreground">{complaint.matricNumber}</p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Category</p>
                          <Badge variant="outline">{categoryLabels[complaint.category]}</Badge>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Status</p>
                          <Badge
                            className={complaint.status === 'resolved' ? 'bg-green-100 text-green-800 hover:bg-green-100' : 'bg-orange-100 text-orange-800 hover:bg-orange-100'}
                          >
                            {complaint.status === 'resolved' ? '✓ Resolved' : '⏱ Pending'}
                          </Badge>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Date</p>
                          <p className="font-semibold">{formatDate(complaint.createdAt)}</p>
                        </div>
                      </div>
                      
                      <div>
                        <p className="text-sm text-muted-foreground mb-2">Complaint</p>
                        <p className="text-foreground line-clamp-2">{complaint.description}</p>
                      </div>

                      <div className="mt-4 text-sm text-muted-foreground">
                        Email: <span className="font-medium text-foreground">{complaint.email}</span>
                      </div>
                    </Card>
                  ))
                )}
              </TabsContent>
            </Tabs>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
