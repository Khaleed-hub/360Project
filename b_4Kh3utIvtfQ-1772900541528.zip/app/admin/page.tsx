'use client'

import { useState } from 'react'
import { useComplaints } from '@/lib/complaint-context'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogTitle } from '@/components/ui/alert-dialog'
import { Empty } from '@/components/ui/empty'
import { CheckCircle2, Clock, Shield } from 'lucide-react'

const categoryLabels: Record<string, string> = {
  academic: 'Academic Issue',
  lecturer: 'Lecturer Complaint',
  result: 'Result Issue',
  registration: 'Course Registration Issue',
  others: 'Others',
}

function formatDate(dateString: string) {
  return new Date(dateString).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  })
}

export default function AdminPanel() {
  const { complaints, updateComplaintStatus } = useComplaints()
  const [selectedComplaint, setSelectedComplaint] = useState<string | null>(null)
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'resolved'>('pending')

  const filteredComplaints = complaints.filter(c =>
    filterStatus === 'all' ? true : c.status === filterStatus
  )

  const pendingCount = complaints.filter(c => c.status === 'pending').length
  const resolvedCount = complaints.filter(c => c.status === 'resolved').length

  const handleResolve = (complaintId: string) => {
    updateComplaintStatus(complaintId, 'resolved')
    setSelectedComplaint(null)
  }

  const handleReopen = (complaintId: string) => {
    updateComplaintStatus(complaintId, 'pending')
    setSelectedComplaint(null)
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      <main className="flex-1">
        <section className="py-12 md:py-24">
          <div className="container mx-auto px-4">
            <div className="flex items-center gap-2 mb-2">
              <Shield className="h-8 w-8 text-primary" />
              <h1 className="text-3xl md:text-4xl font-bold">Admin Panel</h1>
            </div>
            <p className="text-muted-foreground mb-8">
              Manage and respond to student complaints.
            </p>

            {/* Stats Cards */}
            <div className="grid md:grid-cols-2 gap-4 mb-8">
              <Card className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Pending Review</p>
                    <p className="text-3xl font-bold">{pendingCount}</p>
                  </div>
                  <Clock className="h-8 w-8 text-orange-500 opacity-50" />
                </div>
              </Card>

              <Card className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Resolved</p>
                    <p className="text-3xl font-bold">{resolvedCount}</p>
                  </div>
                  <CheckCircle2 className="h-8 w-8 text-green-600 opacity-50" />
                </div>
              </Card>
            </div>

            {/* Management Tabs */}
            <Tabs value={filterStatus} onValueChange={(v) => setFilterStatus(v as 'all' | 'pending' | 'resolved')} className="mb-8">
              <TabsList>
                <TabsTrigger value="pending">Pending ({pendingCount})</TabsTrigger>
                <TabsTrigger value="resolved">Resolved ({resolvedCount})</TabsTrigger>
                <TabsTrigger value="all">All ({complaints.length})</TabsTrigger>
              </TabsList>

              <TabsContent value={filterStatus} className="space-y-4">
                {filteredComplaints.length === 0 ? (
                  <div className="py-12">
                    <Empty
                      title="No complaints"
                      description={
                        filterStatus === 'all'
                          ? 'No complaints have been submitted yet.'
                          : filterStatus === 'pending'
                          ? 'Great! All complaints have been resolved.'
                          : 'No resolved complaints yet.'
                      }
                    />
                  </div>
                ) : (
                  filteredComplaints.map(complaint => (
                    <Card key={complaint.id} className="p-6">
                      <div className="grid md:grid-cols-5 gap-4 items-start mb-4">
                        <div>
                          <p className="text-xs text-muted-foreground uppercase mb-1">Student</p>
                          <p className="font-semibold text-sm">{complaint.studentName}</p>
                          <p className="text-xs text-muted-foreground">{complaint.matricNumber}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground uppercase mb-1">Category</p>
                          <Badge variant="outline" className="text-xs">{categoryLabels[complaint.category]}</Badge>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground uppercase mb-1">Status</p>
                          <Badge
                            className={complaint.status === 'resolved' ? 'bg-green-100 text-green-800 hover:bg-green-100 text-xs' : 'bg-orange-100 text-orange-800 hover:bg-orange-100 text-xs'}
                          >
                            {complaint.status === 'resolved' ? '✓ Resolved' : '⏱ Pending'}
                          </Badge>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground uppercase mb-1">Submitted</p>
                          <p className="text-sm">{formatDate(complaint.createdAt)}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-xs text-muted-foreground uppercase mb-1">Contact</p>
                          <p className="text-xs font-medium truncate">{complaint.email}</p>
                        </div>
                      </div>
                      
                      <div className="mb-4 p-4 bg-muted/50 rounded-lg">
                        <p className="text-xs text-muted-foreground uppercase mb-2">Complaint Details</p>
                        <p className="text-sm text-foreground">{complaint.description}</p>
                      </div>

                      <div className="flex gap-2 justify-end">
                        {complaint.status === 'pending' ? (
                          <Button
                            onClick={() => handleResolve(complaint.id)}
                            className="bg-green-600 hover:bg-green-700"
                          >
                            <CheckCircle2 className="h-4 w-4 mr-2" />
                            Mark as Resolved
                          </Button>
                        ) : (
                          <Button
                            onClick={() => handleReopen(complaint.id)}
                            variant="outline"
                          >
                            <Clock className="h-4 w-4 mr-2" />
                            Reopen
                          </Button>
                        )}
                      </div>
                    </Card>
                  ))
                )}
              </TabsContent>
            </Tabs>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
