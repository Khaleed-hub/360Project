'use client'

import Link from 'next/link'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { FileText, CheckCircle, Users, Shield } from 'lucide-react'

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      <main className="flex-1">
        {/* Hero Section */}
        <section className="py-12 md:py-24 border-b">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center space-y-6">
              <div>
                <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-4">
                  Student Complaint Management System
                </h1>
                <p className="text-lg text-muted-foreground mb-2">
                  Department of Computer Science
                </p>
                <p className="text-sm text-muted-foreground">
                  Ahmadu Bello University Zaria
                </p>
              </div>

              <p className="text-lg text-foreground/80 leading-relaxed">
                A modern platform designed to help students submit complaints about academic or departmental issues, and track responses in real-time.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
                <Link href="/submit-complaint">
                  <Button size="lg" className="w-full sm:w-auto">
                    Submit Complaint
                  </Button>
                </Link>
                <Link href="/complaints">
                  <Button size="lg" variant="outline" className="w-full sm:w-auto">
                    View All Complaints
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-12 md:py-24">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">How It Works</h2>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="p-6 text-center hover:shadow-lg transition-shadow">
                <FileText className="h-12 w-12 mx-auto mb-4 text-primary" />
                <h3 className="font-semibold mb-2">Submit</h3>
                <p className="text-sm text-muted-foreground">
                  Fill out a simple form with your complaint details and category
                </p>
              </Card>

              <Card className="p-6 text-center hover:shadow-lg transition-shadow">
                <Users className="h-12 w-12 mx-auto mb-4 text-primary" />
                <h3 className="font-semibold mb-2">Track</h3>
                <p className="text-sm text-muted-foreground">
                  Monitor your complaint status in the dashboard
                </p>
              </Card>

              <Card className="p-6 text-center hover:shadow-lg transition-shadow">
                <Shield className="h-12 w-12 mx-auto mb-4 text-primary" />
                <h3 className="font-semibold mb-2">Review</h3>
                <p className="text-sm text-muted-foreground">
                  Administrators review and respond to complaints
                </p>
              </Card>

              <Card className="p-6 text-center hover:shadow-lg transition-shadow">
                <CheckCircle className="h-12 w-12 mx-auto mb-4 text-primary" />
                <h3 className="font-semibold mb-2">Resolve</h3>
                <p className="text-sm text-muted-foreground">
                  Get notified when your complaint is resolved
                </p>
              </Card>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-12 md:py-24 bg-primary/5 border-t border-b">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-6">Ready to Submit Your Complaint?</h2>
            <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
              Your voice matters. Submit your complaint today and help us improve our department.
            </p>
            <Link href="/submit-complaint">
              <Button size="lg">Get Started</Button>
            </Link>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
