'use client'

export function Footer() {
  return (
    <footer className="border-t bg-muted/50 py-8">
      <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
        <p className="mb-2">© Student Complaint Management System</p>
        <p>Department of Computer Science</p>
        <p>Ahmadu Bello University Zaria</p>
      </div>
    </footer>
  )
}
