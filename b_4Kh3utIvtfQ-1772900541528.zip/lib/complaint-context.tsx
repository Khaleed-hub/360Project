'use client'

import React, { createContext, useContext, useState, useEffect } from 'react'

export interface Complaint {
  id: string
  studentName: string
  matricNumber: string
  email: string
  category: 'academic' | 'lecturer' | 'result' | 'registration' | 'others'
  description: string
  status: 'pending' | 'resolved'
  createdAt: string
}

interface ComplaintContextType {
  complaints: Complaint[]
  addComplaint: (complaint: Omit<Complaint, 'id' | 'createdAt' | 'status'>) => void
  updateComplaintStatus: (id: string, status: 'pending' | 'resolved') => void
}

const ComplaintContext = createContext<ComplaintContextType | undefined>(undefined)

export function ComplaintProvider({ children }: { children: React.ReactNode }) {
  const [complaints, setComplaints] = useState<Complaint[]>([])
  const [isLoaded, setIsLoaded] = useState(false)

  // Load complaints from localStorage on mount
  useEffect(() => {
    const stored = localStorage.getItem('complaints')
    if (stored) {
      try {
        setComplaints(JSON.parse(stored))
      } catch (error) {
        console.error('Failed to load complaints:', error)
      }
    }
    setIsLoaded(true)
  }, [])

  // Save complaints to localStorage whenever they change
  useEffect(() => {
    if (isLoaded) {
      localStorage.setItem('complaints', JSON.stringify(complaints))
    }
  }, [complaints, isLoaded])

  const addComplaint = (complaint: Omit<Complaint, 'id' | 'createdAt' | 'status'>) => {
    const newComplaint: Complaint = {
      ...complaint,
      id: Date.now().toString(),
      status: 'pending',
      createdAt: new Date().toISOString(),
    }
    setComplaints([newComplaint, ...complaints])
  }

  const updateComplaintStatus = (id: string, status: 'pending' | 'resolved') => {
    setComplaints(complaints.map(c => c.id === id ? { ...c, status } : c))
  }

  return (
    <ComplaintContext.Provider value={{ complaints, addComplaint, updateComplaintStatus }}>
      {children}
    </ComplaintContext.Provider>
  )
}

export function useComplaints() {
  const context = useContext(ComplaintContext)
  if (context === undefined) {
    throw new Error('useComplaints must be used within a ComplaintProvider')
  }
  return context
}
